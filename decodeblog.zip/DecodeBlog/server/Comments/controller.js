const Comment = require("./Comments")

const saveComment = async (req, res) => {
  console.log(req.body);
  res.send("ok")
//   if (req.body.authorId && req.body.blogId) {
//     await new Rate({
//       text: req.body.text,
//       authorId: req.body.authorId,
//       blogId: req.body.blogId,
//       date: Date.now(),
//     }).save();
//     res.status(200).send(true);
//   }
};

module.exports = {
  saveComment,
};
